




step (a)

add the contents of the folder "add_to_codeblocks_mingw_include" into "C:\Program Files\CodeBlocks\MinGW\include"
(or wherever your app\mingw\include is)


step (b)

add the contents of the folder "add_to_codeblocks_mingw_lib" into "C:\Program Files\CodeBlocks\MinGW\lib"
(or wherever your app\mingw\lib is)

